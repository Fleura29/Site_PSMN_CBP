-openproba_Ecoli.bed: file in bedGraph format, contains base-pair opening probabilities (in log10-unit) for the genome of E. coli.

-bubblethresh_Ecoli.bed: file in begGraph format, contains the list of bubbles (start, end and opening probability in log10-unit) whose opening probabilities are higher than 10^(-3), for the genome of E. coli.

-openproba_Bsubtilis.bed: file in bedGraph format, contains base-pair opening probabilities (in log10-unit) for the genome of B. subtilis.

-bubblethresh_Bsubtilis.bed: file in begGraph format, contains the list of bubbles (start, end and opening probability in log10-unit) whose opening probabilities are higher than 10^(-3), for the genome of B. subtilis.